## 1.2.3

* Update godeps for terraform v0.6.3

## 1.2.2

* Convert to go 1.5 vendor experiment
* Update godeps for terraform v0.6.3
